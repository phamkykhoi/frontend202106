### Build Project For Sass

Step1.
    npm init

Step2.
    Run command
    npm install node-sass --save-dev

Step3.
    Run command
    npm install browser-sync --save-dev

Step4.
    Run command
    npm install onchange --save-dev

Step5.
    Run command
    npm install npm-run-all --save-dev

Step6. Config script run compile Sass to CSS

